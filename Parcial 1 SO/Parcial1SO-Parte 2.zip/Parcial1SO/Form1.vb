﻿Public Class Form1
    Dim procesoID As Integer = 0
    Dim maxProcesos As Integer = 5
    Dim WithEvents timerEjecucion As New Timer
    Dim WithEvents timerZombi As New Timer
    Dim WithEvents timerAutomatizacion As New Timer
    Dim prioridad As String() = {"Alta", "Media", "Baja"}

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dgvProcesos.ColumnCount = 3
        dgvProcesos.Columns(0).Name =
        dgvProcesos.Columns(1).Name =
        dgvProcesos.Columns(2).Name =
        dgvProcesos.Columns(0).Width = 100
        dgvProcesos.Columns(1).Width = 150
        dgvProcesos.Columns(2).Width = 100

        timerEjecucion.Interval = 2000
        timerZombi.Interval = 3000
        timerAutomatizacion.Interval = 1000
    End Sub

    'crear un nuevo proceso
    Private Sub btnCrearProceso_Click(sender As Object, e As EventArgs) Handles btnCrearProceso.Click
        If dgvProcesos.Rows.Count <= maxProcesos Then
            procesoID += 1
            Dim fila As String() = New String() {procesoID.ToString(), "Nuevo", prioridad(procesoID Mod 3)}
            dgvProcesos.Rows.Add(fila)
            ActualizarColores()
        Else
            MessageBox.Show("Has alcanzado el máximo de 5 procesos.", "Límite de Procesos")
        End If
    End Sub

    'estado "Listo"
    Private Sub btnAsignarListo_Click(sender As Object, e As EventArgs) Handles btnAsignarListo.Click
        CambiarEstado("Nuevo", "Listo")
    End Sub

    'estado "Ejecución"
    Private Sub btnAsignarEjecucion_Click(sender As Object, e As EventArgs) Handles btnAsignarEjecucion.Click
        CambiarEstado("Listo", "Ejecución")
        timerEjecucion.Start()
    End Sub

    'estado "Bloqueado"
    Private Sub btnAsignarBloqueado_Click(sender As Object, e As EventArgs) Handles btnAsignarBloqueado.Click
        CambiarEstado("Ejecución", "Bloqueado")
    End Sub

    '"Finalizado"
    Private Sub btnAsignarFinalizado_Click(sender As Object, e As EventArgs) Handles btnAsignarFinalizado.Click
        CambiarEstadoAutomatico("Ejecución", "Finalizado")
    End Sub

    Private Sub CambiarEstado(estadoActual As String, nuevoEstado As String)
        If dgvProcesos.SelectedRows.Count > 0 Then
            Dim filaSeleccionada As DataGridViewRow = dgvProcesos.SelectedRows(0)
            If filaSeleccionada.Cells(1).Value = estadoActual Then
                filaSeleccionada.Cells(1).Value = nuevoEstado
                ActualizarColores()
            Else
                MessageBox.Show($"El proceso no está en estado '{estadoActual}'.", "Error")
            End If
        Else
            MessageBox.Show("Selecciona un proceso.", "Advertencia")
        End If
    End Sub

    Private Sub timerEjecucion_Tick(sender As Object, e As EventArgs) Handles timerEjecucion.Tick
        For Each fila As DataGridViewRow In dgvProcesos.Rows
            If fila.Cells(1).Value = "Ejecución" Then
                fila.Cells(1).Value = "Finalizado"
                timerEjecucion.Stop()
                timerZombi.Start()
                Exit For
            End If
        Next
        ActualizarColores()
    End Sub
    'estado zombie
    Private Sub timerZombi_Tick(sender As Object, e As EventArgs) Handles timerZombi.Tick
        For Each fila As DataGridViewRow In dgvProcesos.Rows
            If fila.Cells(1).Value = "Finalizado" Then
                fila.Cells(1).Value = "Zombi"
                ActualizarColores()
                timerZombi.Stop()
                dgvProcesos.Rows.Remove(fila)
                Exit For
            End If
        Next
    End Sub

    'actualizar los colores según el estado
    Private Sub ActualizarColores()
        For Each fila As DataGridViewRow In dgvProcesos.Rows
            Select Case fila.Cells(1).Value
                Case "Nuevo"
                    fila.DefaultCellStyle.BackColor = Color.LightBlue
                Case "Listo"
                    fila.DefaultCellStyle.BackColor = Color.LightGreen
                Case "Ejecución"
                    fila.DefaultCellStyle.BackColor = Color.LightYellow
                Case "Bloqueado"
                    fila.DefaultCellStyle.BackColor = Color.Orange
                Case "Finalizado"
                    fila.DefaultCellStyle.BackColor = Color.LightGray
                Case "Zombi"
                    fila.DefaultCellStyle.BackColor = Color.Red
            End Select
        Next
    End Sub

    ' Automatización del ciclo completo de los procesos
    Private Sub btnAutomatizar_Click(sender As Object, e As EventArgs) Handles btnAutomatizar.Click
        If dgvProcesos.Rows.Count > 0 Then
            timerAutomatizacion.Start()
        Else
            MessageBox.Show("No hay procesos para automatizar.", "Error")
        End If
    End Sub

    Private Sub timerAutomatizacion_Tick(sender As Object, e As EventArgs) Handles timerAutomatizacion.Tick
        For Each fila As DataGridViewRow In dgvProcesos.Rows
            Select Case fila.Cells(1).Value
                Case "Nuevo"
                    fila.Cells(1).Value = "Listo"
                Case "Listo"
                    fila.Cells(1).Value = "Ejecución"
                    timerEjecucion.Start()
                Case "Ejecución"
                    fila.Cells(1).Value = "Finalizado"
                    timerZombi.Start()
            End Select
        Next
        ActualizarColores()
    End Sub

    'ordenar por prioridad
    Private Sub CambiarEstadoAutomatico(estadoActual As String, nuevoEstado As String)
        For Each fila As DataGridViewRow In dgvProcesos.Rows
            If fila.Cells(1).Value = estadoActual Then
                fila.Cells(1).Value = nuevoEstado
                ActualizarColores()
                Exit For
            End If
        Next
    End Sub
End Class
