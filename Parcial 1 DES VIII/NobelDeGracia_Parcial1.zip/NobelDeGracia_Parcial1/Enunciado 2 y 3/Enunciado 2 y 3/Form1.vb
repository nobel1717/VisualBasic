﻿Public Class Form1
    Private Sub btnCalificaciones_Click(sender As Object, e As EventArgs) Handles btnCalificaciones.Click
        Dim frmCalificaciones As New frmCalificaciones
        frmCalificaciones.Show()
    End Sub

    Private Sub btnAhorros_Click(sender As Object, e As EventArgs) Handles btnAhorros.Click
        Dim frmAhorros As New frmAhorros
        frmAhorros.Show()
    End Sub
End Class
